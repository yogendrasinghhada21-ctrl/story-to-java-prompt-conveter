export interface CharacterDetails {
  name: string;
  appearance: string;
  costume: string;
  age: number;
  emotionDefault?: string;
  voiceProfile?: string;
}

export interface SceneCharacter {
  name: string;
  emotion?: string;
}

export interface SceneDetails {
  title: string;
  environment: string;
  camera: string;
  action: string;
  characters: SceneCharacter[];
  narration: string;
}

export interface EngineConfig {
  language?: string;
  voiceEnabled?: boolean;
  voiceProfile?: string;
  narratorProfile?: string;
  stylePreset?: string;
  customStyle?: string;
}

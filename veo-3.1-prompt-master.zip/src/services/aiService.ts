import { GoogleGenAI, Type } from "@google/genai";
import { CharacterDetails, SceneDetails } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function analyzeScript(script: string) {
  const model = "gemini-3-flash-preview";
  
  let attempts = 0;
  const maxAttempts = 3;
  let lastError: any = null;

  while (attempts < maxAttempts) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: `Analyze the following story/script and extract a structured list of characters and a sequence of scenes for high-end cinematic video generation using Veo 3.1.
    
    CRITICAL: Ensure absolute character consistency. Each character must have a unique, detailed, and stable appearance that remains the same across all scenes.
    
    Script:
    ${script}
    
    Return the data in the following JSON format:
    {
      "characters": [
        { 
          "name": "string", 
          "age": number, 
          "appearance": "detailed visual description for consistency", 
          "costume": "specific clothing details", 
          "emotionDefault": "base personality/emotion" 
        }
      ],
      "scenes": [
        { 
          "title": "short descriptive title", 
          "environment": "detailed cinematic setting", 
          "camera": "specific camera movement/angle", 
          "action": "detailed character movement and interaction", 
          "narration": "the exact script for the narrator", 
          "characters": [{ "name": "string", "emotion": "specific emotion for this scene" }] 
        }
      ]
    }`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              characters: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    age: { type: Type.NUMBER },
                    appearance: { type: Type.STRING },
                    costume: { type: Type.STRING },
                    emotionDefault: { type: Type.STRING }
                  },
                  required: ["name", "age", "appearance", "costume"]
                }
              },
              scenes: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    environment: { type: Type.STRING },
                    camera: { type: Type.STRING },
                    action: { type: Type.STRING },
                    narration: { type: Type.STRING },
                    characters: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          name: { type: Type.STRING },
                          emotion: { type: Type.STRING }
                        },
                        required: ["name"]
                      }
                    }
                  },
                  required: ["title", "environment", "camera", "action", "narration", "characters"]
                }
              }
            },
            required: ["characters", "scenes"]
          }
        }
      });

      const data = JSON.parse(response.text || "{}");
      return {
        characters: Array.isArray(data.characters) ? data.characters : [],
        scenes: Array.isArray(data.scenes) ? data.scenes : []
      };
    } catch (e: any) {
      lastError = e;
      const isRateLimit = e.message?.includes("429") || e.message?.includes("RESOURCE_EXHAUSTED");
      
      if (isRateLimit) {
        attempts++;
        if (attempts < maxAttempts) {
          // Exponential backoff: 2s, 4s
          const delay = Math.pow(2, attempts) * 1000;
          await new Promise(resolve => setTimeout(resolve, delay));
          continue;
        }
      }
      throw e;
    }
  }
  throw lastError;
}

import { CharacterDetails, EngineConfig, SceneDetails } from "../types";

export const STYLE_LIBRARY: Record<string, string> = {
  cinematic_realism: "Ultra realistic cinematic lighting, shallow depth of field, film grain, 35mm lens",
  ghibli_emotional: "Soft painterly textures, warm nostalgic glow, anime cinematic framing",
  dark_motivation: "High contrast shadows, neon rim light, intense dramatic mood",
  documentary_news: "Handheld camera feel, natural lighting, realistic urban tone",
  mythological_epic: "Golden divine light rays, grand scale composition, epic atmosphere",
  cozy_asmr: "Macro focus, slow motion particles, warm kitchen lighting",
  sci_fi_future: "Holographic UI reflections, blue cyber glow, futuristic environment",
  village_nostalgia: "Dust particles in sunlight, earthy tones, rural cinematic depth",
  luxury_ad: "Glossy reflections, slow motion elegance, premium color grading",
  horror_psychological: "Fog diffusion, flickering light sources, eerie framing",
  anime_action: "Dynamic speed lines, exaggerated motion blur, vibrant highlights",
  minimal_aesthetic: "Clean background, centered composition, soft gradients",
  historical_drama: "Sepia tint cinematic grade, textured film look",
  motivational_sunrise: "Golden sunrise backlight, hopeful wide framing",
  rain_romance: "Wet reflections, soft rain particles, emotional closeups",
  corporate_modern: "Neutral tones, glass interiors, tech ambience",
  fantasy_magic: "Floating particles, glowing aura effects",
  survival_realistic: "Gritty texture, handheld urgency",
  kids_cartoon: "Bright saturated palette, soft round shapes",
  thriller_fastcut: "Quick zoom transitions, tension lighting"
};

export class VeoPromptEngine {
  language: string;
  voiceEnabled: boolean;
  voiceProfile: string;
  narratorProfile: string;
  characterRegistry: Record<string, CharacterDetails>;
  stylePreset: string;
  customStyle: string;

  constructor(config: EngineConfig = {}) {
    this.language = config.language || "Hindi";
    this.voiceEnabled = config.voiceEnabled ?? true;
    this.voiceProfile = config.voiceProfile || "calm_indian_male";
    this.narratorProfile = config.narratorProfile || "deep_story_narrator";
    this.characterRegistry = {};
    this.stylePreset = config.stylePreset || "cinematic_realism";
    this.customStyle = config.customStyle || "";
  }

  registerCharacter(details: CharacterDetails) {
    this.characterRegistry[details.name] = {
      ...details,
      emotionDefault: details.emotionDefault || "neutral",
      voiceProfile: details.voiceProfile || this.voiceProfile
    };
  }

  getCharacterPrompt(name: string, emotion: string | null = null) {
    const char = this.characterRegistry[name];
    if (!char) return "";

    return `
Character: ${name}
Age: ${char.age}
Appearance: ${char.appearance}
Costume: ${char.costume}
Emotion: ${emotion || char.emotionDefault}
Voice: ${this.voiceEnabled ? char.voiceProfile : "no dialogue"}
`;
  }

  getStylePrompt() {
    let preset = STYLE_LIBRARY[this.stylePreset] || "";
    return (preset + " " + this.customStyle).trim();
  }

  getNarrationBlock(text: string) {
    if (!this.voiceEnabled || !text) return "";

    return `
Narration Language: ${this.language}
Narrator Voice Profile: ${this.narratorProfile}
Narration Script: "${text}"
`;
  }

  buildScene(scene: SceneDetails) {
    let characterPrompts = scene.characters
      .map(c => this.getCharacterPrompt(c.name, c.emotion))
      .filter(p => p !== "")
      .join("\n");

    return `
================= VEO 3.1 SCENE PROMPT =================

Scene Title: ${scene.title}

Environment:
${scene.environment}

Camera:
${scene.camera}

Action:
${scene.action}

Characters:
${characterPrompts}

Visual Style:
${this.getStylePrompt()}

Audio:
${this.getNarrationBlock(scene.narration)}

Output Format: cinematic video

========================================================
`.trim();
  }
}

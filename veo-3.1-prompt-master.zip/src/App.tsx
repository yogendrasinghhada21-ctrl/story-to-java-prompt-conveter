import React, { useState, useMemo } from 'react';
import { 
  Settings, 
  Film, 
  Copy, 
  Check, 
  Sparkles, 
  BookOpen, 
  Loader2,
  Languages,
  Palette,
  ChevronRight,
  User,
  AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { VeoPromptEngine, STYLE_LIBRARY } from './services/veoEngine';
import { analyzeScript } from './services/aiService';
import { CharacterDetails, EngineConfig, SceneDetails } from './types';

export default function App() {
  // --- State ---
  const [config, setConfig] = useState<EngineConfig>({
    language: "Hindi",
    voiceEnabled: true,
    voiceProfile: "calm_indian_male",
    narratorProfile: "deep_story_narrator",
    stylePreset: "cinematic_realism",
    customStyle: ""
  });

  const [characters, setCharacters] = useState<CharacterDetails[]>([]);
  const [script, setScript] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [generatedPrompts, setGeneratedPrompts] = useState<string[]>([]);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [showConfig, setShowConfig] = useState(false);

  // --- Handlers ---
  const handleAIAnalyze = async () => {
    if (!script.trim()) return;
    setIsAnalyzing(true);
    setError(null);
    setGeneratedPrompts([]);
    try {
      const result = await analyzeScript(script);
      const chars = result.characters || [];
      const scns = result.scenes || [];
      
      setCharacters(chars);
      
      // Generate prompts using the engine
      const e = new VeoPromptEngine(config);
      chars.forEach((char: CharacterDetails) => e.registerCharacter(char));
      const prompts = scns.map((s: SceneDetails) => e.buildScene(s));
      setGeneratedPrompts(prompts);
    } catch (err: any) {
      console.error("AI Analysis failed", err);
      if (err.message?.includes("RESOURCE_EXHAUSTED") || err.message?.includes("429")) {
        setError("AI Quota Exceeded. Please wait a moment and try again.");
      } else {
        setError("AI Analysis failed. Please check your script and try again.");
      }
    } finally {
      setIsAnalyzing(false);
    }
  };

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="min-h-screen bg-[#E4E3E0] text-[#141414] font-sans selection:bg-black selection:text-white">
      {/* Header */}
      <header className="border-b border-black p-6 flex justify-between items-center bg-white/40 backdrop-blur-sm sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-black flex items-center justify-center text-white rounded-sm">
            <Film size={24} />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tighter uppercase">Veo 3.1 Prompt Master</h1>
            <p className="text-[10px] uppercase tracking-widest opacity-50 font-mono">AI Script to Prompt Engine</p>
          </div>
        </div>
        <div className="flex gap-4">
          <button 
            onClick={() => setShowConfig(!showConfig)}
            className={`p-2 border border-black transition-colors ${showConfig ? 'bg-black text-white' : 'bg-white hover:bg-black/5'}`}
            title="Style Settings"
          >
            <Settings size={20} />
          </button>
          <button 
            onClick={handleAIAnalyze}
            disabled={isAnalyzing || !script.trim()}
            className="bg-black text-white px-8 py-2 text-xs font-bold uppercase tracking-widest hover:bg-zinc-800 transition-colors flex items-center gap-2 disabled:opacity-30"
          >
            {isAnalyzing ? <Loader2 className="animate-spin" size={14} /> : <Sparkles size={14} />}
            {isAnalyzing ? 'Analyzing...' : 'Generate Prompts'}
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-0 min-h-[calc(100vh-88px)]">
        {/* Left Panel: Input */}
        <div className="lg:col-span-7 border-r border-black flex flex-col bg-white/20">
          <div className="flex-1 p-8 flex flex-col space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest opacity-50">
                <BookOpen size={14} />
                Your Story or Script
              </div>
              <div className="text-[10px] uppercase font-mono bg-black/5 px-2 py-1 rounded flex items-center gap-1">
                <Sparkles size={10} className="text-emerald-600" />
                AI will handle characters & scenes
              </div>
            </div>

            {error && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg text-red-600 text-sm flex items-center gap-3"
              >
                <AlertCircle className="w-5 h-5 flex-shrink-0" />
                <div className="flex-1">
                  <p className="font-bold uppercase text-[10px] tracking-widest mb-1">Analysis Error</p>
                  <p className="text-xs">{error}</p>
                </div>
                <div className="flex flex-col gap-2">
                  <button 
                    onClick={handleAIAnalyze}
                    className="text-red-600 hover:text-red-800 text-xs font-bold uppercase text-left underline underline-offset-2"
                  >
                    Try Again Now
                  </button>
                  <button 
                    onClick={() => setError(null)}
                    className="text-red-600 hover:text-red-800 text-xs font-bold uppercase text-left"
                  >
                    Dismiss
                  </button>
                </div>
              </motion.div>
            )}
            
            <textarea 
              value={script}
              onChange={e => setScript(e.target.value)}
              className="flex-1 w-full bg-white border border-black p-6 text-base focus:outline-none focus:ring-1 focus:ring-black resize-none font-sans leading-relaxed shadow-inner"
              placeholder="Paste your story here... AI will automatically extract characters, maintain their consistency, and build a sequence of cinematic prompts for Veo 3.1."
            />

            <AnimatePresence>
              {showConfig && (
                <motion.div 
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden"
                >
                  <div className="bg-white border border-black p-6 space-y-6 shadow-xl">
                    <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-[11px] uppercase font-bold flex items-center gap-2">
                          <Languages size={12} /> Language
                        </label>
                        <input 
                          type="text" 
                          value={config.language}
                          onChange={e => setConfig({...config, language: e.target.value})}
                          className="w-full bg-zinc-50 border border-black/20 p-2 text-sm focus:border-black outline-none"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[11px] uppercase font-bold flex items-center gap-2">
                          <Palette size={12} /> Style Preset
                        </label>
                        <select 
                          value={config.stylePreset}
                          onChange={e => setConfig({...config, stylePreset: e.target.value})}
                          className="w-full bg-zinc-50 border border-black/20 p-2 text-sm focus:border-black outline-none appearance-none"
                        >
                          {Object.keys(STYLE_LIBRARY).map(key => (
                            <option key={key} value={key}>{key.replace(/_/g, ' ').toUpperCase()}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[11px] uppercase font-bold">Custom Cinematic Style</label>
                      <input 
                        type="text" 
                        value={config.customStyle}
                        onChange={e => setConfig({...config, customStyle: e.target.value})}
                        className="w-full bg-zinc-50 border border-black/20 p-2 text-sm focus:border-black outline-none"
                        placeholder="e.g. slow cinematic motion, emotional Bollywood framing"
                      />
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {characters.length > 0 && (
              <div className="space-y-3 pt-4 border-t border-black/10">
                <h3 className="text-[10px] font-bold uppercase tracking-widest opacity-40 flex items-center gap-2">
                  <User size={12} /> AI Extracted Characters
                </h3>
                <div className="flex flex-wrap gap-2">
                  {characters.map(char => (
                    <div key={char.name} className="bg-black text-white px-3 py-1 text-[10px] font-bold uppercase tracking-wider rounded-full flex items-center gap-2">
                      {char.name}
                      <span className="opacity-50 font-normal">Age {char.age}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Panel: Output */}
        <div className="lg:col-span-5 bg-zinc-900 text-zinc-300 p-0 flex flex-col relative">
          <div className="p-6 border-b border-white/10 flex justify-between items-center bg-zinc-800/50">
            <h2 className="text-xs font-bold uppercase tracking-widest text-white flex items-center gap-2">
              <Film size={14} className="text-emerald-500" />
              Veo 3.1 Prompts ({generatedPrompts.length})
            </h2>
          </div>
          
          <div className="flex-1 p-0 font-mono text-[11px] overflow-auto custom-scrollbar">
            {isAnalyzing ? (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-6 p-12">
                <div className="relative">
                  <Sparkles size={48} className="text-emerald-500 animate-pulse" />
                  <Loader2 size={64} className="absolute -top-2 -left-2 text-white/10 animate-spin" strokeWidth={1} />
                </div>
                <div className="space-y-2">
                  <p className="text-white font-bold uppercase tracking-widest text-xs">AI is Analyzing Script</p>
                  <p className="text-zinc-500 text-[10px] max-w-[200px]">Extracting characters, establishing consistency, and building scenes...</p>
                </div>
              </div>
            ) : generatedPrompts.length > 0 ? (
              <div className="divide-y divide-white/5">
                {generatedPrompts.map((prompt, idx) => (
                  <div key={idx} className="p-8 group relative hover:bg-white/5 transition-colors">
                    <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => copyToClipboard(prompt, idx)}
                        className={`p-2 rounded bg-zinc-800 border border-white/10 ${
                          copiedIndex === idx ? 'text-emerald-500' : 'text-zinc-400 hover:text-white'
                        }`}
                      >
                        {copiedIndex === idx ? <Check size={16} /> : <Copy size={16} />}
                      </button>
                    </div>
                    <div className="mb-4 flex items-center gap-3">
                      <div className="text-[10px] uppercase font-bold text-emerald-500/50">Scene {idx + 1}</div>
                      <div className="h-px flex-1 bg-white/5"></div>
                    </div>
                    <pre className="whitespace-pre-wrap leading-relaxed text-zinc-400">
                      {prompt}
                    </pre>
                  </div>
                ))}
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center opacity-30 space-y-4 p-12">
                <Sparkles size={48} strokeWidth={1} />
                <p className="max-w-[240px]">Paste your script and click "Generate Prompts" to automatically create structured prompts for every scene.</p>
              </div>
            )}
          </div>

          <div className="p-6 border-t border-white/10 bg-zinc-800/30 text-[10px] uppercase tracking-widest opacity-40 flex justify-between items-center">
            <span>Veo 3.1 Master Prompt Engine</span>
            <span className="flex items-center gap-1"><Sparkles size={10} /> AI Powered</span>
          </div>
        </div>
      </main>

      <style dangerouslySetInnerHTML={{ __html: `
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(255, 255, 255, 0.1);
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(255, 255, 255, 0.2);
        }
      `}} />
    </div>
  );
}
